import cv2 as cv
import Connectdata

class Detector:
    face_cascade_name = "venv/Lib/site-packages/cv2/data/haarcascade_frontalface_alt.xml"
    face_cascade = None
    rec = None
    rec_path = "recognizer/trainningData.yml"

    def __init__(self):
        self.face_cascade = cv.CascadeClassifier()
        # -- 1. Load the cascades
        if not self.face_cascade.load(cv.samples.findFile(self.face_cascade_name)):
            print('--(!)Error loading face cascade')
            exit(0)
        self.rec = cv.face.LBPHFaceRecognizer_create()
        self.rec.read(self.rec_path)

    def getProfile(self, id):
        print('do something')

    def detect(self, image):
        image_gray = cv.cvtColor(image, cv.COLOR_BGR2GRAY)
        image_gray = cv.equalizeHist(image_gray)

        #-- Detect face
        faces = self.face_cascade.detectMultiScale(image_gray)


        # set text style
        fontface = cv.FONT_HERSHEY_SIMPLEX
        fontscale = 1
        fontcolor = (255, 0, 0)
        # fontcolor = (203, 23, 252)

        for (x, y, w, h) in faces:
            cv.rectangle(image, (x, y), (x+w, y+h), (255, 255, 0), 1, 8)
            id, loss = self.rec.predict(image_gray[y:y + h, x:x + w])
            print(loss)
            if loss <= 60:
                profile = Connectdata.search(id)
                cv.putText(image, str(profile[0][0]) + "_" + str(profile[0][1]) + "_" + str(profile[0][2]),
                           (x, y), fontface, fontscale, fontcolor, 2)
            else:
                cv.putText(image, "Unknown",
                           (x, y), fontface, fontscale, fontcolor, 2)

        cv.imshow("image", image)
        # cv.waitKey(0)
        # cv.destroyAllWindows()

# path = 'c:/users/le cong hieu/pycharmprojects/face/1.jpg'
# image = cv.imread(path, cv.IMREAD_COLOR)
# # cv.imshow("image", image)
# temp = Detector()
# temp.detect(image)
# cv.waitKey(0)
# cv.destroyAllWindows()


cam = cv.VideoCapture(0)


temp = Detector()
while True:
    # camera read
    ret, img = cam.read()
    temp.detect(img)
    if cv.waitKey(1) == ord('q'):
        break
cam.release()
cv.destroyAllWindows()







