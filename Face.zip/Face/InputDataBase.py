import Connectdata


def inputdata():
    rc = Connectdata.SqliteModel()
    name = input("enter new name: ")
    age = input("enter age: ")
    gen = input("enter gender: ")
    sql="INSERT INTO PEOPLE (Name,Age,Gen) VALUES('{}','{}','{}')".format(name, age, gen)
    rc.Execute(sql)

inputdata()
