import sqlite3


class SqliteModel(object):

    def Connect(self):
        try:
            self.connection = sqlite3.connect('FACEBACE.db')
            self.c = self.connection.cursor()
            return self.c
        except sqlite3.Error as e:
            print("An error occurred:", e.args[0])

    def Db_close(self):
        self.connection.commit()
        self.connection.close()

    def Execute(self,data):
        try:
            self.Connect()
            self.c.execute(data)
            self.Db_close()
        except sqlite3.Error as e:
            print ("An error occurred:", e.args[0])

    def Execute_data(self,data):
        try:
            self.Connect()
            self.c.execute(data)
            self.link_list=self.c.fetchall()
            self.Db_close()
            return self.link_list
        except sqlite3.Error as e:
            print("An error occurred: ",e.args[0])


def search(id):
    rc = SqliteModel()
    sql = "SELECT Name, Age, Gen  FROM PEOPLE WHERE id={}".format(id)
    data = rc.Execute_data(sql)
    return data




