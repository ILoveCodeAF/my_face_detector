import argparse
import os.path
from os import listdir
# from os.path import isdir, join
import imgs

from Sample import Sample

# image = cv.imread("c:/users/le cong hieu/pycharmprojects/face/imgs/duong/1.jpg", cv.IMREAD_COLOR)
# cv.namedWindow("image", cv.WINDOW_AUTOSIZE)
# cv.imshow("image", image)
# cv.waitKey(0)
# cv.destroyAllWindows()


# i = 1
# src = "c:/users/le cong hieu/pycharmprojects/face/imgs/1/"
# temp = Sample()
# while i<=20:
#     path = src + str(i) + ".jpg"
#     temp.loadImage(path)
#     temp.detect()
#     i += 1

# def main():
#
def createSample(src_path, dest_path):
    # print(src_path)
    dirs = []
    files = []
    for obj in listdir(src_path):
        obj_path = os.path.join(src_path, obj)
        if os.path.isdir(obj_path):
            dirs.append(obj)
        else:
            files.append(obj)

    if len(files) > 0:
        base_name = os.path.basename(src_path)
        dest_folder = os.path.join(dest_path, base_name)

        try:
            os.mkdir(dest_folder)
        except OSError:
            if not os.path.isdir(dest_folder):
                raise

        sample = Sample()

        for file in files:
            sample.loadImage(os.path.join(src_path, file))
            is_save = sample.detect()
            if is_save:
                sample.saveImage(os.path.join(dest_folder, file))
    if len(dirs) > 0:
        for dir in dirs:
            createSample(os.path.join(src_path, dir), dest_path)

# cwd = os.path.dirname('c:/users/le cong hieu/pycharmprojects/face/imgs')
# cwd = os.path.basename('c:/users/le cong hieu/pycharmprojects/face/imgs')
# os.getcwd()
# cwd = os.path.join('c:/users/le cong hieu/pycharmprojects/face/imgs', "1")
# print(os.path.isdir(cwd))

parser = argparse.ArgumentParser(description="code to create samples")
parser.add_argument('--path', help='path to directory', default='imgs')
arg = parser.parse_args()

path = arg.path

if os.path.isdir(path):
    dest_path = 'dataset'

    try:
        os.mkdir(dest_path)
    except:
        if not os.path.isdir(dest_path):
            raise
    createSample(path, dest_path)
else:
    print("error: path <"+path+"> doesn't exist")

# print(path)
# print(os.path.isdir('c:/users/le cong hieu/pycharmprojects/face/imgs/1/'))
# print(os.path.isdir('c:/users/le cong hieu/pycharmprojects/face/imgs/1/133.jpg'))
# print(os.path.exists('c:/users/le cong hieu/pycharmprojects/face/imgs/1/133.jpg'))