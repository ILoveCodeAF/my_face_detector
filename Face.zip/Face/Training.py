# from os import listdir
from os import listdir
from os import mkdir
from os.path import isdir
from os.path import join
from os.path import basename
from PIL import Image
import numpy as np
import argparse
import cv2 as cv


# for f in listdir("c:/users/le cong hieu/pycharmprojects/face/imgs/1"):
#     print(f)

class Training:
    ids = []
    faces = []

    def __init__(self):
        return

    def getImagesAndLabels(self, path):
        print(path)
        if isdir(path):
            dirs = []
            files = []

            for obj in listdir(path):
                obj_path = join(path, obj)
                if isdir(obj_path):
                    dirs.append(obj)
                else:
                    files.append(obj)

            if len(files) > 0:
                label = int(basename(path))
                print("label: "+ str(label))

                for file in files:
                    face_image = Image.open(join(path, file)).convert('L')
                    data = np.array(face_image, 'uint8')

                    self.ids.append(label)
                    self.faces.append(data)
                    # display image and label
                    # set text style
                    # fontface = cv.FONT_HERSHEY_SIMPLEX
                    # fontscale = 1
                    # fontcolor = (203, 23, 252)
                    # cv.putText(data, "label: "+str(label), (0, 40), fontface, fontscale, fontcolor, 1)
                    # cv.imshow('image', data)
                    # cv.waitKey(0)
                    # cv.destroyAllWindows()
            if len(dirs) > 0:
                for dir in dirs:
                    self.getImagesAndLabels(join(path, dir))
        else:
            print("error: path <"+path+"> is not a directory!")
        # print(len(self.ids))

    def trainning(self):
        if len(self.ids) == 0 or len(self.faces) == 0:
            print("Error: no data!!")
        else:
            recognizer = cv.face.LBPHFaceRecognizer_create()
            # training
            recognizer.train(self.faces, np.array(self.ids))
            path = 'recognizer/'
            try:
                mkdir(path)
            except:
                if not isdir(path):
                    raise

            recognizer.save(join(path, 'trainningData.yml'))


parse = argparse.ArgumentParser(description="Tranning...")
parse.add_argument('--path', help = 'path to directory', default='dataset')
arg = parse.parse_args()

path = arg.path
if isdir(path):
    training = Training()
    training.getImagesAndLabels(path)
    training.trainning()
else:
    print("error: path <"+path+"> is not directoty!!")
# from PIL import Image
# import numpy as np
# import cv2 as cv
# image  = Image.open('c:/users/le cong hieu/pycharmprojects/face/imgs/1/1.jpg').convert('L')
# img = np.array(image, 'uint8')
# print(image.mode)
# cv.imshow("image", img)
# cv.waitKey(0)
# cv.destroyAllWindows()