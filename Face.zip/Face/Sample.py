import numpy as np
import cv2 as cv



class Sample:
    image = None
    sample_image = None
    face_cascade_name = "venv/Lib/site-packages/cv2/data/haarcascade_frontalface_alt.xml"
    def __init__(self):
        self.face_cascade = cv.CascadeClassifier()
        # -- 1. Load the cascades
        if not self.face_cascade.load(cv.samples.findFile(self.face_cascade_name)):
            print('--(!)Error loading face cascade')
            exit(0)

    def loadImage(self, path):
        self.image = cv.imread(path, cv.IMREAD_COLOR)
        self.sample_image = None
        if self.image is None:
            print("cant read image: " + path)
            return False
        return True

    def detect(self):
        ret = True
        if self.image is None:
            print("image is not loaded!")
            return
        image_gray = cv.cvtColor(self.image, cv.COLOR_BGR2GRAY)
        image_gray = cv.equalizeHist(image_gray)

        #-- Detect face
        faces = self.face_cascade.detectMultiScale(self.image)

        posX = posY = maxW = maxH = 0
        for (x, y, w, h) in faces:
            if(w+h > maxW+maxH):
                posX = x
                posY = y
                maxW = w
                maxH = h

        if maxW + maxH != 0:
            self.sample_image = image_gray[posY:posY+maxH, posX:posX+maxW]
            cv.rectangle(self.image, (posX, posY), (posX + maxW, posY + maxH), (255, 0, 0), 2)
        else:
            ret = False

        if not self.image is None:
            cv.namedWindow("image", cv.WINDOW_AUTOSIZE)
            cv.imshow("image", self.image)
        if (not self.sample_image is None) and ret :
            cv.namedWindow("sample", cv.WINDOW_AUTOSIZE)
            cv.imshow("sample", self.sample_image)
        cv.waitKey(0)
        cv.destroyAllWindows()
        return ret

    def saveImage(self, filename):
        if not self.sample_image is None:
            cv.imwrite(filename, self.sample_image)